/*#################################################################*/
/*###############            F�CEIS                 ###############*/
/*#################################################################*/

/* F.01
 * Crie uma fun��o que receba a quantidade n de termos e imprima os 
 * n termos da sequ�ncia de fibonacci. */
 
 void fibonacci(int n);
 
 /* F.02
 * Fa�a  uma fun��o que  receba  um vetor de inteiros de tamanho 15,
 * j� prenchido pelo usu�rio, passe este vetor para uma fun��o. 
 * Dentro da fun��o determine ent�o qual o 
 * maior e o menor destes n�meros e quantas vezes este maior e este 
 * menor ocorrem no vetor. No final, apresente esses valores.*/
 
 void maior_menor(int vetor[], int tamanho);
 
 /* F.03
 * Fa�a uma fun��o que receba um vetor A de 10 elementos e construa
 * um vetor B que possui os mesmos n�meros de A, sendo que na ordem 
 * invertida. Imprima o vetor B*/
 
 void inverter(int vetor_A[], int tamanho);

/*#################################################################*/
/*###############            M�DIAS                 ###############*/
/*#################################################################*/

/*M.01
 * Escreva  uma  fun��o  que  receba  um  vetor  A  de  10  elementos  
 * ponto  flutuante  e construa um vetor B formado da seguinte maneira:

 * Regras
 * Se �ndice i �mpar   B[i] = A[i] / 2
 * Se �ndice i par   B[i] = A[i] * 3

 * Em sequida mostre o vetor B
*/

void vetor_par_impar(float vetorA[], int tamanho);

/* M.02
 * Fa�a uma fun��o que receba como par�metro um vetor A de dez elementos 
 * inteiros j� populado como par�metro. Ao final dessa fun��o, dever� ter sido 
 * gerado um vetor B contendo o fatorial de cada elementos de A. O vetor B 
 * dever� ser mostrado.*/
 
 void vetor_fatorial(int vetorA[], int tamanho);

/*#################################################################*/
/*###############            DIF�CEIS               ###############*/
/*#################################################################*/

/*
* Busca Bin�ria � um processo de busca em vetores ordenados que tira proveito 
* desta ordena��o para ser substancialmente mais r�pida que a busca linear . 
* A busca bin�ria por um elemento x em um vetor M ordenado segue as etapas,
* i. Definir os contadores i e j e inici�-los respectivamente com as posi��es
* inicial e final de M.
* ii. Se i for menor que j a busca se encerra sem sucesso.
* iii. Determinar a posi��o k m�dia entre as posi��es i e j .
* iv. Se o elemento Mk for igual a x a busca termina com sucesso.
* v. Se Mk for maior que x ent�o j recebe k - 1 e volta-se a etapa-ii.
* vi. Se Mk for menor que x ent�o i recebe k + 1 e volta-se a etapa-ii.
* Dados como entrada um vetor V ordenado de inteiros e um inteiro x,
* determinar por busca bin�ria se x pertence ou n�o a V .*/

void busca_binaria(int vetor[], int tamanho, int x);
