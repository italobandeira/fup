/*#################################################################*/
/*###############            F�CEIS                 ###############*/
/*#################################################################*/

/* F.01
 * Elabore um programa que receba um n�mero do usu�rio e informe 
 * se � par ou �mpar.  */
 
 void par_ou_impar(int num){
      if(num%2==0)
          printf("Numero par.");
      else
          printf("Numero impar");
      } 
      
/* F.02
 * Determinar o valor m�ximo de dois n�meros A e B dados como 
 * entrada. */
 
 int valor_maximo(int a, int b){
     if(a>b)
          return a;
     else
         return b;
     }
     
/* F.03
 * Dados dois n�meros naturais como entrada, determinar o resto da divis�o do maior
 * pelo menor quando poss�vel. */
 
 int resto_divisao(int n1, int n2){
     //caso o n1 seja 0 e o maior ent�o retorna -1 como mensagem de erro.
     if(n1==0 || n2==0)
              return -1;
     else{
          if(n1>n2)
                   return n1%n2;
          else
                   return n2%n1;
          }
     
     }
     
 /* F.04
 * Fa�a um algoritmo que receba dois n�meros inteiros e verifique se h� 
 * a seguinte situa��o se o n1 est� entre 50 e 200 e n2 est� entre -1 e 9.
 * A sa�da deve ser 1 seos n�meros satisfazem a situa��o e 0 
 * se n�o satisfazem. */
 
 int satisfaz_situacao(int n1, int n2){
     if(n1>=50 && n1<=200 && n2>=-1 && n2<=9)
               return 1;
     else
               return 0;
     }
     
 /*#################################################################*/
/*###############            M�DIAS                 ###############*/
/*#################################################################*/
 
 /* M.01
 *Fa�a um algoritmo que determina o IMC (�ndice da massa corp�rea) de uma 
 *pessoa e indique se ela esta magra, normal ou obesa. O IMC � calculado com o 
 *peso em kg, dividido pelo quadrado da altura, em metros, IMC = Peso/Altura2. Se o
 *IMC � menor que 20 estamos magros. Se o IMC est� acima de 25 estamos 
 *obesos. Se o IMC estiver entre 20 e 25 estamos normais.*/

 void IMC(int peso, int altura){
      int imc = peso/(altura*altura);
      if(imc<20)
           printf("MAGRO");
      else if(imc>20 && imc<25)
           printf("NORMAL");
      else if(imc>25)
           printf("OBESO");
      }
      
 /* M.02
 * Escreva um programa que l� tr�s n�meros correspondentes aos comprimentos 
 * dos lados de um tri�ngulo e decide (imprime) se o tri�ngulo � equil�tero,
 * is�sceles ou escaleno. */

 void tipo_triangulo(int l1, int l2, int l3){
      if (l1 + l2 >= l3 && l1 + l3 >= l2 && l2 + l3 >= l1)
         {
          if (l1 == l2 && l2 == l3 && l3 == l1){
             printf ("Triangulo Equilatero");
             }
          else if (l1 == l2 || l2 == l3 || l3 == l1){
             printf ("Triangulo Isosceles");
             }
          else if (l1 != l2 && l2 != l3 && l3 != l1){
             printf ("Triangulo Escaleno");
             }
         }
      else
          printf ("Valores invalidos para formar um triangulo");
      }
 
 /*#################################################################*/
/*###############            DIF�CEIS               ###############*/
/*#################################################################*/

/* D.01
 * Receber 3 n�meros inteiros como entrada e reescrev�-los em ordem 
 * crescente. */
 
 void ordem_crescente(int n1, int n2, int n3){
      //n1 � o maior
    if (n1 < n2 && n1 < n3 ){
        if (n2 < n3){
            printf("%d %d %d", n1,n2,n3);
        }
        else
            printf("%d %d %d", n1,n3,n2);
    }
    //n2 � o maior
    if (n2 < n1 && n2 < n3){
        if ( n1 < n3){
            printf("%d %d %d", n2,n1,n3);
        }
        else
            printf("%d %d %d", n2,n3,n1);
    }
 
    //n3 � o maior
    if (n3 < n1 && n3 < n2 ){
        if ( n1 < n2 ){
            printf("%d %d %d", n3,n1,n2);
        }
        else
            printf("%d %d %d", n3,n2,n1);
    }
 
    if (n1 == n2 && n2 == n3 ){
        printf("%d %d %d", n1,n2,n3);
    }
      }
 
